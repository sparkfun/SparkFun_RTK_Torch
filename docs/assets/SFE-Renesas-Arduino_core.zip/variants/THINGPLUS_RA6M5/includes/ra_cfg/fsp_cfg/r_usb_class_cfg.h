/* generated configuration header file - do not edit */
#ifndef R_USB_CLASS_CFG_H_
#define R_USB_CLASS_CFG_H_

#endif /* R_USB_CLASS_CFG_H_ */
