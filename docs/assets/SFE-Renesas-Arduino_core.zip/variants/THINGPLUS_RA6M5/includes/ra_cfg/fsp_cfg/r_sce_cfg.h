/* generated configuration header file - do not edit */
#ifndef R_SCE_CFG_H_
#define R_SCE_CFG_H_
#define SCE_RSA_RETRY_COUNT_FOR_RSA_KEY_GENERATION 10240
#define SCE_USER_SHA_384_ENABLED                   (0)
#define SCE_USER_SHA_384_FUNCTION                  crypto_sha384_user_function
#endif /* R_SCE_CFG_H_ */
